# Mybatis SQL 매퍼 폴더

Mybatisdml DAO 구현체가 사용할 SQL 매퍼 파일을 두는 곳