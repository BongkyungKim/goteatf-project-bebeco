# Thymeleaf 템플릿 디렉토리

Thymeleaf 뷰 렌더링 엔진이 사용할 템플릿 파일을 두는 곳