function hello() {
  alert('안녕하세요!!');
}