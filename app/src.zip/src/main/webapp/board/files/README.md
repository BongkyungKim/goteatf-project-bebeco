# /webapp/board/files 폴더

클라이언트가 업로드한 파일을 저장하는 폴더이다.