# VO 패키지

Value Object(Domain,DTO)를 두는 곳