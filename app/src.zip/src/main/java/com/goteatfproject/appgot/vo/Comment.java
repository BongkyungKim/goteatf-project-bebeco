//package com.goteatfproject.appgot.vo;
//
//import lombok.Getter;
//import lombok.Setter;
//import lombok.ToString;
//
//@Getter @Setter @ToString
//public class Comment {
//
//  private int no;
//  private String content;
//  private boolean pub;
//
//  private Member writer;
////  private Party partyPage;
//}
