# /src/test/resources

단위 테스트 실행에 관련된 설정 파일이나 기타 파일을 두는 곳